# 🚀 Quick Start Guide - Friday Bazar Dynamic Menu System

## ✅ Bot is Ready!

The Friday Bazar bot is now running with the new **dynamic menu system**. All menus are loaded from the database!

---

## 🎯 How to Test

### 1. Start the Bot

```bash
cd "c:\Users\prava\OneDrive\Desktop\Primium bot"
python main.py
```

**You should see:**
```
[OK] Legacy database initialized
[OK] Dynamic menu database initialized
[OK] User command menu set (6 commands)
[OK] Admin command menu set for 1 admin(s)
[OK] Bot polling started
[WEB] Server started on 0.0.0.0:8080
```

### 2. Test in Telegram

Open your bot: **@friday_bazar_bot**

#### Test /start Command
```
/start
```

**Expected Result:**
- Welcome message from Main Menu
- 5 buttons arranged in grid:
  ```
  [🛒 Start Payment]
  [💰 My Friday Coins] [🔗 Referral Link]
  [🆘 Help] [📞 Contact Support]
  ```

#### Test Navigation
1. Click **"🛒 Start Payment"**
   - Should show Services Menu
   - 3 service options + back button

2. Click **"🎬 YouTube Premium"**
   - Shows plan details
   - Price: ₹25 (originally ₹129)
   - Features list
   - "Pay ₹25 Now" button

3. Click **"◀️ Back"**
   - Returns to Services Menu

#### Test Custom Actions
1. Click **"💰 My Friday Coins"**
   - Shows balance: ₹0.00
   - Total referrals: 0
   - Total earnings: ₹0.00

2. Click **"🔗 Referral Link"**
   - Shows your referral link
   - Explains 10% commission

3. Click **"🆘 Help"**
   - Shows help text
   - Purchase instructions

4. Click **"📞 Contact Support"**
   - Shows support info
   - Support hours

---

## 📊 What's Different Now

### Before (Hardcoded)
```python
# Old way - hardcoded in keyboards/menus.py
keyboard = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="🛒 Start Payment", ...)]
])
```

### After (Dynamic from Database) ✅
```python
# New way - loaded from database
menu = await db.get_menu_by_name("Main Menu")
buttons = await db.get_menu_buttons(menu.menu_id)
await render_menu(user_id, menu.menu_id, bot)
```

**All menus are now in:** `data/friday_bazar.db`

---

## 🔧 Database Management

### View Database Contents

```bash
# Open database
sqlite3 data/friday_bazar.db

# List all menus
SELECT name, content_type FROM menus;

# List all buttons
SELECT menu_id, text, type FROM buttons;

# List all payment plans
SELECT name, price, duration_days FROM payment_plans;

# Exit
.exit
```

### Current Database Structure

**Menus:**
- Main Menu (ID: `menu_116e7449`)
- Premium Services (ID: `services_menu`)

**Payment Plans:**
- YouTube Premium - ₹25 (365 days)
- Zee5 Premium - ₹180 (365 days)  
- Spotify Premium - ₹149 (365 days)

---

## 🎨 How to Modify Menus (For Now)

Until we build the Admin Panel UI (Phase 3), you can modify menus via:

### Option 1: Direct Database Edit
```bash
sqlite3 data/friday_bazar.db

# Change Main Menu welcome text
UPDATE menus 
SET content_data = 'New welcome message!' 
WHERE name = 'Main Menu';

# Change button text
UPDATE buttons 
SET text = '🎉 New Button Text' 
WHERE button_id = 'btn_xxx';
```

### Option 2: Python Script
Create a script to update menus programmatically:

```python
import asyncio
from database.db_manager import db

async def update_menu():
    await db.initialize()
    
    # Get menu
    menu = await db.get_menu_by_name("Main Menu")
    menu.content_data = "Updated welcome message!"
    
    # Save
    await db.update_menu(menu)
    print("Menu updated!")

asyncio.run(update_menu())
```

### Option 3: Wait for Phase 3 Admin Panel 🎯
With the admin panel, you'll be able to edit menus directly from Telegram chat!

---

## 🐛 Troubleshooting

### Bot Won't Start

**Error:** `ModuleNotFoundError: No module named 'aiogram.client.default'`
- **Fixed!** ✅ Updated imports for aiogram 3.3.0

**Error:** `BOT_TOKEN is not set`
- Check `.env` file has your bot token

### Menus Not Showing

**Issue:** Bot sends error message  
- Run migrations: `python -m database.migrations.seed_default_data`

**Issue:** Old menus showing
- Dynamic router is registered first, should override old handlers

### Database Errors

**Error:** `no such table: menus`
- Database not initialized
- Run: `python -m database.migrations.seed_default_data`

---

## 📁 Important Files

### Database
- `data/friday_bazar.db` - SQLite database with all menus

### Core System
- `database/models.py` - Data models
- `database/db_manager.py` - Database operations
- `core/menu_renderer.py` - Menu rendering engine
- `core/action_handler.py` - Button click routing
- `handlers/user_dynamic.py` - Dynamic /start handler

### Migrations
- `database/migrations/seed_default_data.py` - Create default menus
- `database/migrations/migrate_json_data.py` - Import existing data

---

## ✨ What's Next?

### Phase 3: Admin Panel (Coming Next!)

Build admin UI in Telegram to manage menus without code:

```
/admin → 🎛️ Admin Panel

[📋 Menu Manager] - Create/edit menus
[💬 Content Editor] - Edit text/images
[💳 Payment Plans] - Manage plans
[👥 User Manager] - View users
[📊 Statistics] - Analytics
```

**Features:**
- Create new menu wizard (step-by-step)
- Add/remove buttons visually
- Edit content with live preview
- Manage payment plans
- Everything from Telegram chat!

**Would you like me to start building Phase 3?**

---

## 🎉 Success!

Your bot now has:
- ✅ Dynamic menu loading from database
- ✅ 8 button actions working
- ✅ 3 payment plans configured
- ✅ Session tracking
- ✅ Referral system integrated
- ✅ No hardcoded menus!

**Test it now and see the magic! 🚀**
