# Friday Bazar Payment Bot 🛒

A production-ready, modular Telegram bot for selling premium subscriptions with UPI payments, inline keyboard navigation, and integrated referral system.

## 🎯 Features

- **💸 Inline Menu System**: Clean inline keyboard buttons directly in messages
- **📦 Service Catalog**: Dynamic service grid with premium subscriptions (Zee5, YouTube, Spotify, etc.)
- **💳 UPI Payment System**: QR code generation with automatic expiration timers
- **🎁 Referral Economy**: Earn 10% commission on referrals (1 Coin = ₹1)
- **👨‍💼 Admin Panel**: Screenshot verification & order approval workflow
- **🔙 Back Navigation**: All pages have back buttons to main menu
- **🔄 Async Architecture**: Built with aiogram v3 + asyncio
- **☁️ Render Ready**: Deploys on Render Free Tier with health server

## 📁 Project Structure

```
Primium bot/
├── main.py                    # Entry point with web server
├── requirements.txt
├── .env.example
├── src/
│   ├── config.py             # Configuration
│   ├── data/
│   │   └── services.py       # Service catalog
│   ├── handlers/
│   │   ├── user.py           # /start, help, back navigation
│   │   ├── catalog.py        # Service grid & details
│   │   ├── payment.py        # QR generation & timers
│   │   ├── referrals.py      # Referral links & coins
│   │   ├── admin.py          # Admin approval
│   │   ├── language.py       # Multi-language support
│   │   └── misc.py           # Additional handlers
│   ├── services/
│   │   ├── db.py             # JSON database
│   │   └── subscription.py   # Subscription management
│   ├── keyboards/
│   │   └── menus.py          # All inline keyboards
│   └── utils/
│       └── helpers.py        # QR generation, etc.
├── core/
│   ├── action_handler.py     # Button click routing
│   └── menu_renderer.py      # Dynamic menu system
└── data/                     # Auto-created on first run
    ├── users.json
    └── orders.json
```

## 🚀 Quick Start

### 1. Clone & Install

```bash
cd "Primium bot"
pip install -r requirements.txt
```

### 2. Configure Environment

```bash
cp .env.example .env
```

Edit `.env` and set:

```env
BOT_TOKEN=your_bot_token_from_botfather
BOT_USERNAME=YourBotUsername
ADMIN_IDS=123456789,987654321
UPI_ID=yourupi@paytm
UPI_NAME=Your Name
SUPPORT_USERNAME=YourSupportUsername
```

### 3. Run Locally

```bash
python main.py
```

The bot will start on `http://0.0.0.0:8080` with health endpoint at `/health`

## ☁️ Deploy to Render

### 1. Create Web Service on Render

- **Build Command**: `pip install -r requirements.txt`
- **Start Command**: `python main.py`
- **Environment**: Python 3

### 2. Set Environment Variables

Add these in Render Dashboard:

| Variable | Example |
|----------|---------|
| `BOT_TOKEN` | `123456:ABCdef...` |
| `BOT_USERNAME` | `FridayBazarBot` |
| `ADMIN_IDS` | `123456789` |
| `UPI_ID` | `yourname@paytm` |
| `UPI_NAME` | `Friday Bazar` |
| `SUPPORT_USERNAME` | `SupportUsername` |
| `PORT` | `8080` (auto-set by Render) |

## 🎨 Main Menu Structure

The bot uses **inline keyboard buttons** (not persistent reply keyboard):

```
💸 Start Payment          (Full width)
📱 Telegram Accounts      (Full width)
🌑 My Friday Coins | 🔗 Referral Link
📜 Terms of Service       (Full width)
📞 Contact | 🆘 Help
```

All buttons include **🔙 Back to Main Menu** navigation.

## 🔄 Purchase Flow

1. User sends `/start` → Inline menu appears
2. User clicks **💸 Start Payment** → Service grid shown
3. User selects service (e.g., "Zee5") → Plans displayed
4. User clicks price → UPI QR code generated
5. User pays via UPI → Uploads payment screenshot
6. Admin receives notification → Approves/Rejects
7. **On Approval**:
   - User provides email/details
   - Referrer earns 10% coins (if applicable)
   - Purchase added to user history
   - User notified with credentials

## 💰 Referral System

- **Link Format**: `https://t.me/BotUsername?start=ref_123456`
- **Commission**: 10% of purchase amount
- **Payout**: Coins credited instantly on order approval
- **Stats Tracked**: Total referrals, total earnings, current balance
- **View Stats**: Click "🌑 My Friday Coins" in main menu

## 🔙 Navigation System

Every page has a back button:
- Service screens → Back to services or main menu
- Payment screens → Back to main menu after cancel
- Info screens (Coins, Referral, Help, Contact) → Back to main menu
- Language selection → Back to main menu

## 🛠️ Customization

### Add/Edit Services

Edit `src/data/services.py`:

```python
"service_id": {
    "name": "Service Name",
    "emoji": "🎬",
    "instruction": "Custom activation instructions...",
    "plans": [
        {"duration": "1 Year", "price": 180, "original_price": 299}
    ],
    "available": True  # Set to False for demo/coming soon
}
```

### Change Commission Rate

Edit `.env`:

```env
REFERRAL_COMMISSION_PERCENT=15
```

### Payment Timeout

Edit `.env`:

```env
PAYMENT_TIMEOUT_MINUTES=10
```

## 🌐 Multi-Language Support

The bot supports:
- 🇬🇧 English
- 🇮🇳 Hindi (हिंदी)
- 🇧🇩 Bengali (বাংলা)

Users can change language with `/language` command.

## 🔍 Admin Commands

- `/start` - Access the bot
- `/admin` - Show admin panel info
- `/dashboard` - Admin dashboard with full management
- `/help` - Display help information
- `/language` - Change language preference

**Admin receives automatic notifications for:**
- Payment verification requests (with screenshot)
- User details after approval

## 📝 Technical Details

- **Framework**: aiogram v3.3.0
- **Database**: Async JSON files (no external DB needed)
- **Timers**: Auto-expire unpaid orders after timeout
- **FSM**: User states managed via aiogram FSM
- **Message Types**: Handles both text and photo messages
- **Health Endpoint**: `/health` for Render monitoring
- **Web Server**: aiohttp for health checks

## 🐛 Troubleshooting

### Port Already in Use Error

If you get `OSError: [Errno 10048]`:

```powershell
# Kill existing Python processes
Get-Process python | Stop-Process -Force

# Then restart
python main.py
```

### Bot not starting?
- Check `BOT_TOKEN` in `.env`
- Ensure all required environment variables are set
- Verify bot token is valid from @BotFather

### Back buttons not working?
- Restart the bot completely
- The fix handles both text and photo messages
- Check logs for any errors

### Payments not working?
- Verify `UPI_ID` is correct
- Check `UPI_NAME` is set
- Ensure admin IDs are configured correctly

### Referrals not crediting?
- User must click referral link BEFORE first purchase
- Check `REFERRAL_COMMISSION_PERCENT` is set
- Coins are credited only after admin approval

## 📄 License

MIT License - Use freely for your projects!

---

**Built with ❤️ using aiogram v3**

**Current Version**: Inline Keyboard Edition with Full Back Navigation
