"""
Friday Bazar Core System Package
=================================
Core functionality for dynamic menu rendering and routing
"""

__all__ = ['menu_renderer', 'action_handler', 'state_manager']
