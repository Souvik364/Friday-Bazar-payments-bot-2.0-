"""
Multi-language translations for YouTube Premium Bot
Supports: English, Bengali (বাংলা), Hindi (हिन्दी)
"""

TRANSLATIONS = {
    "en": {
        "language_name": "English",
        "welcome": "👋 <b>Welcome to YouTube Premium Bot, {}!</b>\n\n"
                  "🎥 Get <b>YouTube Premium + YouTube Music</b> at affordable prices!\n\n"
                  "✨ <b>What you get:</b>\n"
                  "• 🚫 <b>Ad-Free Videos</b> - No interruptions\n"
                  "• 🎵 <b>YouTube Music Premium</b> - Unlimited music\n"
                  "• 📥 <b>Download Videos</b> - Watch offline anytime\n"
                  "• 📱 <b>Background Play</b> - Listen with screen off\n"
                  "• 🎬 <b>YouTube Originals</b> - Exclusive content\n"
                  "• 🎶 <b>High Quality Audio</b> - Premium sound\n\n"
                  "💡 <i>Click the button below to view our premium plans!</i>",
        "youtube_premium": "🎥 YouTube Premium",
        "help": "ℹ️ Help",
        "my_status": "📊 My Status",
        "support": "💬 Support",
        "change_language": "🌐 Change Language",
        "select_language": "🌐 <b>Select Your Language</b>\n\n"
                          "Please choose your preferred language:\n"
                          "अपनी पसंदीदा भाषा चुनें:\n"
                          "আপনার পছন্দের ভাষা নির্বাচন করুন:",
        "language_changed": "✅ Language changed to English!",
        "choose_plan": "🎥 <b>Choose Your YouTube Premium Plan</b>\n\n"
                      "🎯 <b>Includes YouTube Music Premium!</b>\n\n"
                      "🔹 <b>1 Month</b> - ₹20\n"
                      "   • Ad-free videos\n"
                      "   • Background play\n"
                      "   • Download videos\n"
                      "   • YouTube Music included\n\n"
                      "🔹 <b>3 Months</b> - ₹55 🔥\n"
                      "   • <i>Save ₹5! Most Popular!</i>\n"
                      "   • All features for 3 months\n"
                      "   • Best value for money\n\n"
                      "🔜 <b>6 Months</b> - ₹100 (Coming Soon)\n"
                      "   • <i>Save ₹20! Available soon!</i>\n\n"
                      "💡 Click a button below to proceed:",
        "back_menu": "🔙 Back to Menu",
        "coming_soon": "🔜 Coming Soon",
        "upload_now": "📸 Upload Screenshot Now",
        "cancel_payment": "🔙 Cancel & Go Back",
        "payment_details": "🎥 <b>YouTube Premium Payment</b>\n\n"
                          "📦 Plan: <b>{}</b>\n"
                          "💰 Amount: <b>₹{}</b>\n\n"
                          "🎁 <b>Includes:</b>\n"
                          "• 🚫 Ad-free videos\n"
                          "• 🎵 YouTube Music Premium\n"
                          "• 📥 Download videos\n"
                          "• 📱 Background play\n\n"
                          "📱 <b>Scan this QR code to pay</b>\n\n"
                          "⏰ Timer: <b>5 minutes</b>\n"
                          "⏱️ Ends at: {}\n\n"
                          "✅ <b>Upload screenshot anytime within 5 minutes!</b>\n"
                          "No need to wait - upload as soon as you complete payment.",
        "timer_started": "⏱️ <b>Timer Started!</b>\n\n"
                        "🎯 You can upload your payment screenshot <b>anytime</b> within the next 5 minutes.\n\n"
                        "📸 <b>Just send the photo directly</b> or click 'Upload Screenshot Now' button.\n\n"
                        "💡 <i>Tip: Upload immediately after payment to get YouTube Premium faster!</i>",
        "screenshot_received": "✅ <b>Screenshot Received!</b>\n\n"
                              "📧 <b>One last step!</b>\n\n"
                              "Please reply with the <b>Email ID</b> where you want to activate YouTube Premium.\n\n"
                              "📝 <i>Type your email below...</i>",
        "invalid_email": "⚠️ <b>Invalid Email Format</b>\n\n"
                        "Please send a valid email address (e.g., example@gmail.com).",
        "submission_complete": "🎉 <b>Submission Successful!</b>\n\n"
                              "✅ Payment Screenshot: Received\n"
                              "✅ Email: <b>{}</b>\n\n"
                              "⏳ <b>Admin is reviewing your request.</b>\n"
                              "You will receive a notification here once approved.\n\n"
                              "📞 <b>For further enquiry:</b>\n"
                              "Contact Admin for support if needed.",
        "approved": "🎉 <b>CONGRATULATIONS!</b> 🎉\n\n"
                   "✅ Your payment has been <b>APPROVED</b>!\n\n"
                   "🎥 <b>Your YouTube Premium is Now ACTIVE!</b>\n\n"
                   "🎁 <b>Features Unlocked:</b>\n"
                   "• ✅ Ad-free YouTube videos\n"
                   "• ✅ YouTube Music Premium\n"
                   "• ✅ Download videos & music\n"
                   "• ✅ Background playback\n"
                   "• ✅ YouTube Originals access\n\n"
                   "💡 Type /status to view your subscription details\n\n"
                   "🙏 <i>Thank you for choosing YouTube Premium!</i>",
        "rejected": "❌ <b>Payment Verification Failed</b>\n\n"
                   "Unfortunately, your payment could not be verified.\n\n"
                   "📝 <b>Possible Reasons:</b>\n"
                   "• Incorrect payment amount\n"
                   "• Incomplete transaction details\n"
                   "• Payment not received\n\n"
                   "💡 <b>What to do next:</b>\n"
                   "• Double-check your payment\n"
                   "• Try again with correct details\n"
                   "• Contact support for help\n\n"
                   "📞 Need assistance? Use /support to contact support.",
        "support_text": "💬 <b>Need Help?</b>\n\n"
                       "Contact our support team: {}\n\n"
                       "🕐 <b>Response Time:</b> Usually within 1 hour\n"
                       "📝 <b>What to include:</b>\n"
                       "• Your User ID: <code>{}</code>\n"
                       "• Payment screenshot\n"
                       "• Issue description",
    },
    
    "bn": {
        "language_name": "বাংলা",
        "welcome": "👋 <b>YouTube Premium বটে স্বাগতম, {}!</b>\n\n"
                  "🎥 সাশ্রয়ী মূল্যে <b>YouTube Premium + YouTube Music</b> পান!\n\n"
                  "✨ <b>আপনি যা পাবেন:</b>\n"
                  "• 🚫 <b>বিজ্ঞাপন-মুক্ত ভিডিও</b> - কোনো বাধা নেই\n"
                  "• 🎵 <b>YouTube Music Premium</b> - সীমাহীন সঙ্গীত\n"
                  "• 📥 <b>ভিডিও ডাউনলোড</b> - যেকোনো সময় অফলাইনে দেখুন\n"
                  "• 📱 <b>ব্যাকগ্রাউন্ড প্লে</b> - স্ক্রিন বন্ধ রেখে শুনুন\n"
                  "• 🎬 <b>YouTube Originals</b> - এক্সক্লুসিভ কন্টেন্ট\n"
                  "• 🎶 <b>উচ্চ মানের অডিও</b> - প্রিমিয়াম সাউন্ড\n\n"
                  "💡 <i>আমাদের প্রিমিয়াম প্ল্যান দেখতে নিচের বাটনে ক্লিক করুন!</i>",
        "youtube_premium": "🎥 YouTube Premium",
        "help": "ℹ️ সাহায্য",
        "my_status": "📊 আমার স্ট্যাটাস",
        "support": "💬 সাপোর্ট",
        "change_language": "🌐 ভাষা পরিবর্তন",
        "select_language": "🌐 <b>আপনার ভাষা নির্বাচন করুন</b>\n\n"
                          "অনুগ্রহ করে আপনার পছন্দের ভাষা চয়ন করুন:\n"
                          "Please choose your preferred language:\n"
                          "अपनी पसंदीदा भाषा चुनें:",
        "language_changed": "✅ ভাষা বাংলায় পরিবর্তন করা হয়েছে!",
        "choose_plan": "🎥 <b>আপনার YouTube Premium প্ল্যান বেছে নিন</b>\n\n"
                      "🎯 <b>YouTube Music Premium অন্তর্ভুক্ত!</b>\n\n"
                      "🔹 <b>১ মাস</b> - ₹20\n"
                      "   • বিজ্ঞাপন-মুক্ত ভিডিও\n"
                      "   • ব্যাকগ্রাউন্ড প্লে\n"
                      "   • ভিডিও ডাউনলোড\n"
                      "   • YouTube Music অন্তর্ভুক্ত\n\n"
                      "🔹 <b>৩ মাস</b> - ₹55 🔥\n"
                      "   • <i>₹5 সাশ্রয়! সবচেয়ে জনপ্রিয়!</i>\n"
                      "   • ৩ মাসের জন্য সব ফিচার\n"
                      "   • সবচেয়ে ভালো ভ্যালু\n\n"
                      "🔜 <b>৬ মাস</b> - ₹100 (শীঘ্রই আসছে)\n"
                      "   • <i>₹20 সাশ্রয়! শীঘ্রই উপলব্ধ!</i>\n\n"
                      "💡 এগিয়ে যেতে নিচের বাটনে ক্লিক করুন:",
        "back_menu": "🔙 মেনুতে ফিরুন",
        "coming_soon": "🔜 শীঘ্রই আসছে",
        "upload_now": "📸 এখনই স্ক্রিনশট আপলোড করুন",
        "cancel_payment": "🔙 বাতিল করুন এবং ফিরে যান",
        "payment_details": "🎥 <b>YouTube Premium পেমেন্ট</b>\n\n"
                          "📦 প্ল্যান: <b>{}</b>\n"
                          "💰 পরিমাণ: <b>₹{}</b>\n\n"
                          "🎁 <b>অন্তর্ভুক্ত:</b>\n"
                          "• 🚫 বিজ্ঞাপন-মুক্ত ভিডিও\n"
                          "• 🎵 YouTube Music Premium\n"
                          "• 📥 ভিডিও ডাউনলোড\n"
                          "• 📱 ব্যাকগ্রাউন্ড প্লে\n\n"
                          "📱 <b>পেমেন্ট করতে এই QR কোড স্ক্যান করুন</b>\n\n"
                          "⏰ টাইমার: <b>৫ মিনিট</b>\n"
                          "⏱️ শেষ হবে: {}\n\n"
                          "✅ <b>৫ মিনিটের মধ্যে যেকোনো সময় স্ক্রিনশট আপলোড করুন!</b>\n"
                          "অপেক্ষা করার প্রয়োজন নেই - পেমেন্ট সম্পন্ন করার সাথে সাথে আপলোড করুন।",
        "timer_started": "⏱️ <b>টাইমার শুরু হয়েছে!</b>\n\n"
                        "🎯 আপনি পরবর্তী ৫ মিনিটের মধ্যে <b>যেকোনো সময়</b> আপনার পেমেন্ট স্ক্রিনশট আপলোড করতে পারবেন।\n\n"
                        "📸 <b>সরাসরি ছবি পাঠান</b> অথবা 'Upload Screenshot Now' বাটনে ক্লিক করুন।\n\n"
                        "💡 <i>টিপ: দ্রুত YouTube Premium পেতে পেমেন্টের পরপরই আপলোড করুন!</i>",
        "screenshot_received": "✅ <b>স্ক্রিনশট প্রাপ্ত হয়েছে!</b>\n\n"
                              "📧 <b>আর একটি ধাপ বাকি!</b>\n\n"
                              "অনুগ্রহ করে সেই <b>ইমেল আইডি</b> পাঠান যেখানে আপনি YouTube Premium চালু করতে চান।\n\n"
                              "📝 <i>নিচে আপনার ইমেল টাইপ করুন...</i>",
        "invalid_email": "⚠️ <b>ভুল ইমেল ফরম্যাট</b>\n\n"
                        "অনুগ্রহ করে একটি সঠিক ইমেল ঠিকানা দিন (যেমন: example@gmail.com)।",
        "submission_complete": "🎉 <b>সফলভাবে জমা দেওয়া হয়েছে!</b>\n\n"
                              "✅ পেমেন্ট স্ক্রিনশট: গৃহীত\n"
                              "✅ ইমেল: <b>{}</b>\n\n"
                              "⏳ <b>অ্যাডমিন আপনার অনুরোধ পর্যালোচনা করছেন।</b>\n"
                              "অনুমোদিত হলে আপনি এখানে নোটিফিকেশন পাবেন।\n\n"
                              "📞 <b>আরও তথ্যের জন্য:</b>\n"
                              "প্রয়োজনে সাপোর্টে যোগাযোগ করুন।",
        "approved": "🎉 <b>অভিনন্দন!</b> 🎉\n\n"
                   "✅ আপনার পেমেন্ট <b>অনুমোদিত হয়েছে</b>!\n\n"
                   "🎥 <b>আপনার YouTube Premium এখন সক্রিয়!</b>\n\n"
                   "🎁 <b>আনলক করা ফিচার:</b>\n"
                   "• ✅ বিজ্ঞাপন-মুক্ত YouTube ভিডিও\n"
                   "• ✅ YouTube Music Premium\n"
                   "• ✅ ভিডিও এবং মিউজিক ডাউনলোড\n"
                   "• ✅ ব্যাকগ্রাউন্ড প্লেব্যাক\n"
                   "• ✅ YouTube Originals অ্যাক্সেস\n\n"
                   "💡 আপনার সাবস্ক্রিপশন বিবরণ দেখতে /status টাইপ করুন\n\n"
                   "🙏 <i>YouTube Premium বেছে নেওয়ার জন্য ধন্যবাদ!</i>",
        "rejected": "❌ <b>পেমেন্ট যাচাই ব্যর্থ হয়েছে</b>\n\n"
                   "দুর্ভাগ্যবশত, আপনার পেমেন্ট যাচাই করা যায়নি।\n\n"
                   "📝 <b>সম্ভাব্য কারণ:</b>\n"
                   "• ভুল পেমেন্ট পরিমাণ\n"
                   "• অসম্পূর্ণ লেনদেন বিবরণ\n"
                   "• পেমেন্ট প্রাপ্ত হয়নি\n\n"
                   "💡 <b>পরবর্তী করণীয়:</b>\n"
                   "• আপনার পেমেন্ট দুবার চেক করুন\n"
                   "• সঠিক বিবরণ দিয়ে আবার চেষ্টা করুন\n"
                   "• সাহায্যের জন্য সাপোর্টে যোগাযোগ করুন\n\n"
                   "📞 সহায়তা প্রয়োজন? /support ব্যবহার করুন।",
        "support_text": "💬 <b>সাহায্য দরকার?</b>\n\n"
                       "আমাদের সাপোর্ট টিমের সাথে যোগাযোগ করুন: {}\n\n"
                       "🕐 <b>প্রতিক্রিয়া সময়:</b> সাধারণত ১ ঘণ্টার মধ্যে\n"
                       "📝 <b>কী অন্তর্ভুক্ত করবেন:</b>\n"
                       "• আপনার ইউজার আইডি: <code>{}</code>\n"
                       "• পেমেন্ট স্ক্রিনশট\n"
                       "• সমস্যার বিবরণ",
    },
    
    "hi": {
        "language_name": "हिन्दी",
        "welcome": "👋 <b>YouTube Premium बॉट में आपका स्वागत है, {}!</b>\n\n"
                  "🎥 किफायती कीमतों पर <b>YouTube Premium + YouTube Music</b> प्राप्त करें!\n\n"
                  "✨ <b>आपको क्या मिलेगा:</b>\n"
                  "• 🚫 <b>विज्ञापन-মুক্ত वीडियो</b> - कोई रुकावट नहीं\n"
                  "• 🎵 <b>YouTube Music Premium</b> - असीमित संगीत\n"
                  "• 📥 <b>वीडियो डाउनलोड करें</b> - कभी भी ऑफलाइन देखें\n"
                  "• 📱 <b>बैकग्राउंड प्ले</b> - स्क्रीन बंद करके सुनें\n"
                  "• 🎬 <b>YouTube Originals</b> - विशेष सामग्री\n"
                  "• 🎶 <b>उच्च गुणवत्ता ऑडियो</b> - प्रीमियम ध्वनि\n\n"
                  "💡 <i>हमारे प्रीमियम प्लान देखने के लिए नीचे बटन पर क्लिक करें!</i>",
        "youtube_premium": "🎥 YouTube Premium",
        "help": "ℹ️ मदद",
        "my_status": "📊 मेरी स्थिति",
        "support": "💬 सहायता",
        "change_language": "🌐 भाषा बदलें",
        "select_language": "🌐 <b>अपनी भाषा चुनें</b>\n\n"
                          "कृपया अपनी पसंदीदा भाषा चुनें:\n"
                          "Please choose your preferred language:\n"
                          "अपनी पसंदीदा भाषा चुनें:",
        "language_changed": "✅ भाषा हिन्दी में बदल गई!",
        "choose_plan": "🎥 <b>अपना YouTube Premium प्लान चुनें</b>\n\n"
                      "🎯 <b>YouTube Music Premium शामिल!</b>\n\n"
                      "🔹 <b>1 महीना</b> - ₹20\n"
                      "   • विज्ञापन-মুক্ত वीडियो\n"
                      "   • बैकग्राउंड प्ले\n"
                      "   • वीडियो डाउनलोड\n"
                      "   • YouTube Music शामिल\n\n"
                      "🔹 <b>3 महीने</b> - ₹55 🔥\n"
                      "   • <i>₹5 बचाएं! सबसे लोकप्रिय!</i>\n"
                      "   • 3 महीने के लिए सभी सुविधाएं\n"
                      "   • सबसे अच्छी वैल्यू\n\n"
                      "🔜 <b>6 महीने</b> - ₹100 (जल्द आ रहा है)\n"
                      "   • <i>₹20 बचाएं! जल्द उपलब्ध!</i>\n\n"
                      "💡 आगे बढ़ने के लिए नीचे बटन पर क्लिक करें:",
        "back_menu": "🔙 मेनू पर वापस",
        "coming_soon": "🔜 जल्द आ रहा है",
        "upload_now": "📸 अभी स्क्रीनशॉट अपलोड करें",
        "cancel_payment": "🔙 रद्द करें और वापस जाएं",
        "payment_details": "🎥 <b>YouTube Premium पेमेंट</b>\n\n"
                          "📦 प्लान: <b>{}</b>\n"
                          "💰 राशि: <b>₹{}</b>\n\n"
                          "🎁 <b>शामिल:</b>\n"
                          "• 🚫 विज्ञापन-मुक्त वीडियो\n"
                          "• 🎵 YouTube Music Premium\n"
                          "• 📥 वीडियो डाउनलोड\n"
                          "• 📱 बैकग्राउंड प्ले\n\n"
                          "📱 <b>भुगतान के लिए इस QR कोड को स्कैन करें</b>\n\n"
                          "⏰ टाइमर: <b>5 मिनट</b>\n"
                          "⏱️ समाप्त होगा: {}\n\n"
                          "✅ <b>5 मिनट के भीतर कभी भी स्क्रीनशॉट अपलोड करें!</b>\n"
                          "प्रतीक्षा करने की आवश्यकता नहीं - भुगतान पूरा होते ही अपलोड करें।",
        "timer_started": "⏱️ <b>टाइमर शुरू हो गया!</b>\n\n"
                        "🎯 आप अगले 5 मिनट के भीतर <b>कभी भी</b> अपना भुगतान स्क्रीनशॉट अपलोड कर सकते हैं।\n\n"
                        "📸 <b>सीधे फोटो भेजें</b> या 'Upload Screenshot Now' बटन पर क्लिक करें।\n\n"
                        "💡 <i>टिप: तेजी से YouTube Premium पाने के लिए भुगतान के तुरंत बाद अपलोड करें!</i>",
        "screenshot_received": "✅ <b>स्क्रीनशॉट प्राप्त हुआ!</b>\n\n"
                              "📧 <b>एक आखिरी कदम!</b>\n\n"
                              "कृपया वह <b>ईमेल आईडी</b> भेजें जिस पर आप YouTube Premium सक्रिय करना चाहते हैं।\n\n"
                              "📝 <i>अपना ईमेल नीचे टाइप करें...</i>",
        "invalid_email": "⚠️ <b>अमान्य ईमेल प्रारूप</b>\n\n"
                        "कृपया एक मान्य ईमेल पता भेजें (जैसे: example@gmail.com)।",
        "submission_complete": "🎉 <b>सफलतापूर्वक जमा किया गया!</b>\n\n"
                              "✅ भुगतान स्क्रीनशॉट: प्राप्त हुआ\n"
                              "✅ ईमेल: <b>{}</b>\n\n"
                              "⏳ <b>एडमिन आपके अनुरोध की समीक्षा कर रहा है।</b>\n"
                              "स्वीकृत होने पर आपको यहां सूचित किया जाएगा।\n\n"
                              "📞 <b>अधिक जानकारी के लिए:</b>\n"
                              "यदि आवश्यक हो तो सहायता के लिए एडमिन से संपर्क करें।",
        "approved": "🎉 <b>बधाई हो!</b> 🎉\n\n"
                   "✅ आपका भुगतान <b>स्वीकृत</b> हो गया है!\n\n"
                   "🎥 <b>आपका YouTube Premium अब सक्रिय है!</b>\n\n"
                   "🎁 <b>अनलॉक की गई सुविधाएं:</b>\n"
                   "• ✅ विज्ञापन-मुक्त YouTube वीडियो\n"
                   "• ✅ YouTube Music Premium\n"
                   "• ✅ वीडियो और संगीत डाउनलोड\n"
                   "• ✅ बैकग्राउंड प्लेबैक\n"
                   "• ✅ YouTube Originals एक्सेस\n\n"
                   "💡 अपने सदस्यता विवरण देखने के लिए /status टाइप करें\n\n"
                   "🙏 <i>YouTube Premium चुनने के लिए धन्यवाद!</i>",
        "rejected": "❌ <b>भुगतान सत्यापन विफल</b>\n\n"
                   "दुर्भाग्य से, आपके भुगतान को सत्यापित नहीं किया जा सका।\n\n"
                   "📝 <b>संभावित कारण:</b>\n"
                   "• गलत भुगतान राशि\n"
                   "• अधूरे लेनदेन विवरण\n"
                   "• भुगतान प्राप्त नहीं हुआ\n\n"
                   "💡 <b>अब क्या करें:</b>\n"
                   "• अपने भुगतान की दोबारा जांच करें\n"
                   "• सही विवरण के साथ फिर से प्रयास करें\n"
                   "• सहायता के लिए सपोर्ट से संपर्क करें\n\n"
                   "📞 सहायता चाहिए? /support का उपयोग करें।",
        "support_text": "💬 <b>मदद चाहिए?</b>\n\n"
                       "हमारी सपोर्ट टीम से संपर्क करें: {}\n\n"
                       "🕐 <b>प्रतिक्रिया समय:</b> आमतौर पर 1 घंटे के भीतर\n"
                       "📝 <b>क्या शामिल करें:</b>\n"
                       "• आपकी यूजर ID: <code>{}</code>\n"
                       "• भुगतान स्क्रीनशॉट\n"
                       "• समस्या का विवरण",
    }
}


def get_text(lang: str, key: str, *args) -> str:
    """
    Get translated text for the given language and key.
    Falls back to English if language or key not found.
    """
    if lang not in TRANSLATIONS:
        lang = "en"
    
    text = TRANSLATIONS.get(lang, TRANSLATIONS["en"]).get(key, TRANSLATIONS["en"].get(key, ""))
    
    if args:
        try:
            return text.format(*args)
        except:
            return text
    return text


def get_language_keyboard():
    """Get inline keyboard for language selection."""
    from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
    
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🌐 English", callback_data="lang_en")],
            [InlineKeyboardButton(text="🌐 हिन्दी (Hindi)", callback_data="lang_hi")],
            [InlineKeyboardButton(text="🌐 বাংলা (Bengali)", callback_data="lang_bn")]
        ]
    )
    return keyboard
