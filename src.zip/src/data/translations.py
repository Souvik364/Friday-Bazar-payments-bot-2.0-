"""
Friday Bazar Payments - Multi-Language Translations
====================================================
Translations for English, Hindi, and Bengali
"""

TRANSLATIONS = {
    "en": {
        # Welcome & Start
        "welcome_title": "🎉 **Welcome to Friday Bazar!**",
        "welcome_message": (
            "Get premium subscriptions at unbeatable prices:\n"
            "✨ Zee5, YouTube, Spotify & more\n"
            "💰 Instant activation\n"
            "🎁 Earn coins through referrals\n\n"
            "Tap **🛒 Start Payment** to browse our services!"
        ),
        "referred_by": "✅ You've been referred by user {referrer_id}!\nThey'll earn 10% commission when you make your first purchase.",
        
        # Language Selection
        "select_language": "🌐 **Select Your Language / भाषा चुनें / ভাষা নির্বাচন করুন**\n\nChoose your preferred language:",
        "language_changed": "✅ Language changed to English!",
        
        # Buttons
        "btn_start_payment": "🛒 Start Payment",
        "btn_telegram_accounts": "📱 Telegram Accounts",
        "btn_my_coins": "💰 My Friday Coins",
        "btn_referral_link": "🔗 Referral Link",
        "btn_terms": "📄 Terms of Service",
        "btn_contact": "📞 Contact",
        "btn_help": "🆘 Help",
        "btn_language": "🌐 Language",
        "btn_status": "📊 My Status",
        
        # Services
        "select_service": "🛍️ **Select a Service**\n\nChoose from our premium subscription services:",
        "select_plan": "💰 **Select a Plan:**",
        
        # Payment
        "payment_details": "💳 **Payment Details**",
        "service": "🛍️ Service",
        "plan": "⏱️ Plan",
        "amount": "💰 Amount",
        "order_id": "🆔 Order ID",
        "complete_by": "⏰ Complete payment before",
        "scan_qr": "📲 **Scan the QR code** or pay to:",
        "upi_id": "UPI ID",
        "important": "⚠️ **Important:**",
        "payment_instructions": (
            "• Use the exact amount shown\n"
            "• Keep your payment screenshot ready\n"
            "• Click 'I've Paid' after completing payment"
        ),
        "upload_screenshot": "📸 **Upload Payment Screenshot**\n\nPlease send a clear screenshot of your payment confirmation.",
        "screenshot_received": "✅ **Screenshot Received!**\n\nYour payment is being verified by our team.\nYou'll be notified once approved (usually within 5-10 minutes).",
        
        # Admin
        "payment_approved": "✅ **Payment Approved!**\n\n🎉 Your payment for **{service}** ({plan}) has been verified.",
        "provide_details": "📧 **Next Step:**\nPlease provide your details for account activation:",
        "details_instructions": (
            "For most services, we need:\n"
            "• Email Address or Mobile Number\n"
            "• Any specific account details\n\n"
            "Please send this information now:"
        ),
        "details_received": "✅ **Details Received!**\n\nThank you! Your **{service}** account will be activated within 24 hours.",
        "payment_rejected": "❌ **Payment Verification Failed**\n\nUnfortunately, we couldn't verify your payment for order `{order_id}`.",
        
        # Referrals
        "referral_link_title": "🎁 **Your Referral Link**",
        "referral_message": "Share this link and earn **10% commission** on every purchase made by your referrals!",
        "your_link": "🔗 **Your Link:**",
        "your_stats": "💰 **Your Stats:**",
        "coins": "• Friday Coins",
        "total_referrals": "• Total Referrals",
        "total_earned": "• Total Earned",
        "how_it_works": "💡 **How it works:**",
        "referral_steps": (
            "1. Share your link with friends\n"
            "2. They sign up using your link\n"
            "3. When they make a purchase, you earn 10%\n"
            "4. Coins are added instantly to your balance"
        ),
        
        # Support
        "contact_support": "📞 **Contact Support**\n\nNeed help? Our support team is here for you!",
        "support_hours": "⏰ **Support Hours:**\nMonday - Saturday: 9 AM - 9 PM IST\nSunday: 10 AM - 6 PM IST",
        
        # Help
        "help_title": "🆘 **Help & FAQ**",
        "help_purchase": "**How to Purchase:**",
        "help_steps": (
            "1. Tap 🛒 Start Payment\n"
            "2. Select a service\n"
            "3. Choose your plan\n"
            "4. Scan QR & pay\n"
            "5. Upload payment screenshot\n"
            "6. Wait for approval"
        ),
        
        # Status
        "status_title": "📊 **Your Status**",
        "subscription_active": "✅ **Subscription Active**",
        "subscription_expired": "❌ **Subscription Expired**",
        "no_subscription": "ℹ️ **No Active Subscription**",
        "expires_on": "Expires on",
        
        # Errors
        "error_generic": "❌ An error occurred. Please try again.",
        "error_unauthorized": "❌ You are not authorized for this action.",
        "canceled": "✅ Operation canceled.",
    },
    
    "hi": {
        # Welcome & Start
        "welcome_title": "🎉 **फ्राइडे बाजार में आपका स्वागत है!**",
        "welcome_message": (
            "बेहतरीन कीमतों पर प्रीमियम सब्सक्रिप्शन पाएं:\n"
            "✨ Zee5, YouTube, Spotify और भी बहुत कुछ\n"
            "💰 तुरंत सक्रियण\n"
            "🎁 रेफरल से कॉइन्स कमाएं\n\n"
            "हमारी सेवाएं देखने के लिए **🛒 भुगतान शुरू करें** पर टैप करें!"
        ),
        "referred_by": "✅ आपको यूजर {referrer_id} ने रेफर किया है!\nजब आप पहली खरीदारी करेंगे तो उन्हें 10% कमीशन मिलेगा।",
        
        # Language Selection
        "select_language": "🌐 **अपनी भाषा चुनें / Select Language / ভাষা নির্বাচন করুন**\n\nअपनी पसंदीदा भाषा चुनें:",
        "language_changed": "✅ भाषा हिंदी में बदल गई!",
        
        # Buttons
        "btn_start_payment": "🛒 भुगतान शुरू करें",
        "btn_telegram_accounts": "📱 टेलीग्राम अकाउंट",
        "btn_my_coins": "💰 मेरे फ्राइडे कॉइन्स",
        "btn_referral_link": "🔗 रेफरल लिंक",
        "btn_terms": "📄 सेवा की शर्तें",
        "btn_contact": "📞 संपर्क करें",
        "btn_help": "🆘 मदद",
        "btn_language": "🌐 भाषा",
        "btn_status": "📊 मेरी स्थिति",
        
        # Services
        "select_service": "🛍️ **एक सेवा चुनें**\n\nहमारी प्रीमियम सब्सक्रिप्शन सेवाओं में से चुनें:",
        "select_plan": "💰 **एक प्लान चुनें:**",
        
        # Payment
        "payment_details": "💳 **भुगतान विवरण**",
        "service": "🛍️ सेवा",
        "plan": "⏱️ प्लान",
        "amount": "💰 राशि",
        "order_id": "🆔 ऑर्डर आईडी",
        "complete_by": "⏰ इससे पहले भुगतान पूरा करें",
        "scan_qr": "📲 **QR कोड स्कैन करें** या यहां भुगतान करें:",
        "upi_id": "UPI आईडी",
        "important": "⚠️ **महत्वपूर्ण:**",
        "payment_instructions": (
            "• दिखाई गई सही राशि का उपयोग करें\n"
            "• अपना भुगतान स्क्रीनशॉट तैयार रखें\n"
            "• भुगतान पूरा करने के बाद 'मैंने भुगतान किया' पर क्लिक करें"
        ),
        "upload_screenshot": "📸 **भुगतान स्क्रीनशॉट अपलोड करें**\n\nकृपया अपनी भुगतान पुष्टि का स्पष्ट स्क्रीनशॉट भेजें।",
        "screenshot_received": "✅ **स्क्रीनशॉट प्राप्त हुआ!**\n\nआपके भुगतान की हमारी टीम द्वारा जांच की जा रही है।\nस्वीकृत होने पर आपको सूचित किया जाएगा (आमतौर पर 5-10 मिनट में)।",
        
        # Admin
        "payment_approved": "✅ **भुगतान स्वीकृत!**\n\n🎉 **{service}** ({plan}) के लिए आपका भुगतान सत्यापित हो गया है।",
        "provide_details": "📧 **अगला चरण:**\nकृपया खाता सक्रियण के लिए अपना विवरण प्रदान करें:",
        "details_instructions": (
            "अधिकांश सेवाओं के लिए हमें चाहिए:\n"
            "• ईमेल पता या मोबाइल नंबर\n"
            "• कोई विशिष्ट खाता विवरण\n\n"
            "कृपया अब यह जानकारी भेजें:"
        ),
        "details_received": "✅ **विवरण प्राप्त हुआ!**\n\nधन्यवाद! आपका **{service}** खाता 24 घंटों के भीतर सक्रिय हो जाएगा।",
        "payment_rejected": "❌ **भुगतान सत्यापन विफल**\n\nदुर्भाग्य से, हम ऑर्डर `{order_id}` के लिए आपके भुगतान को सत्यापित नहीं कर सके।",
        
        # Referrals
        "referral_link_title": "🎁 **आपका रेफरल लिंक**",
        "referral_message": "यह लिंक शेयर करें और अपने रेफरल की हर खरीदारी पर **10% कमीशन** कमाएं!",
        "your_link": "🔗 **आपका लिंक:**",
        "your_stats": "💰 **आपके आंकड़े:**",
        "coins": "• फ्राइडे कॉइन्स",
        "total_referrals": "• कुल रेफरल",
        "total_earned": "• कुल कमाई",
        "how_it_works": "💡 **यह कैसे काम करता है:**",
        "referral_steps": (
            "1. अपने दोस्तों के साथ लिंक शेयर करें\n"
            "2. वे आपके लिंक का उपयोग करके साइन अप करते हैं\n"
            "3. जब वे खरीदारी करते हैं, तो आप 10% कमाते हैं\n"
            "4. कॉइन्स तुरंत आपके बैलेंस में जोड़े जाते हैं"
        ),
        
        # Support
        "contact_support": "📞 **सहायता से संपर्क करें**\n\nमदद चाहिए? हमारी सहायता टीम आपके लिए यहां है!",
        "support_hours": "⏰ **सहायता समय:**\nसोमवार - शनिवार: सुबह 9 बजे - रात 9 बजे IST\nरविवार: सुबह 10 बजे - शाम 6 बजे IST",
        
        # Help
        "help_title": "🆘 **मदद और FAQ**",
        "help_purchase": "**कैसे खरीदें:**",
        "help_steps": (
            "1. 🛒 भुगतान शुरू करें पर टैप करें\n"
            "2. एक सेवा चुनें\n"
            "3. अपना प्लान चुनें\n"
            "4. QR स्कैन करें और भुगतान करें\n"
            "5. भुगतान स्क्रीनशॉट अपलोड करें\n"
            "6. स्वीकृति की प्रतीक्षा करें"
        ),
        
        # Status
        "status_title": "📊 **आपकी स्थिति**",
        "subscription_active": "✅ **सब्सक्रिप्शन सक्रिय**",
        "subscription_expired": "❌ **सब्सक्रिप्शन समाप्त**",
        "no_subscription": "ℹ️ **कोई सक्रिय सब्सक्रिप्शन नहीं**",
        "expires_on": "समाप्ति तिथि",
        
        # Errors
        "error_generic": "❌ एक त्रुटि हुई। कृपया पुनः प्रयास करें।",
        "error_unauthorized": "❌ आप इस कार्रवाई के लिए अधिकृत नहीं हैं।",
        "canceled": "✅ ऑपरेशन रद्द किया गया।",
    },
    
    "bn": {
        # Welcome & Start
        "welcome_title": "🎉 **ফ্রাইডে বাজারে আপনাকে স্বাগতম!**",
        "welcome_message": (
            "অপ্রতিরোধ্য দামে প্রিমিয়াম সাবস্ক্রিপশন পান:\n"
            "✨ Zee5, YouTube, Spotify এবং আরও অনেক কিছু\n"
            "💰 তাৎক্ষণিক সক্রিয়করণ\n"
            "🎁 রেফারেলের মাধ্যমে কয়েন অর্জন করুন\n\n"
            "আমাদের পরিষেবাগুলি ব্রাউজ করতে **🛒 পেমেন্ট শুরু করুন** ট্যাপ করুন!"
        ),
        "referred_by": "✅ আপনাকে ব্যবহারকারী {referrer_id} রেফার করেছেন!\nআপনার প্রথম ক্রয়ে তারা 10% কমিশন পাবেন।",
        
        # Language Selection
        "select_language": "🌐 **আপনার ভাষা নির্বাচন করুন / Select Language / भाषा चुनें**\n\nআপনার পছন্দের ভাষা চয়ন করুন:",
        "language_changed": "✅ ভাষা বাংলায় পরিবর্তিত হয়েছে!",
        
        # Buttons
        "btn_start_payment": "🛒 পেমেন্ট শুরু করুন",
        "btn_telegram_accounts": "📱 টেলিগ্রাম অ্যাকাউন্ট",
        "btn_my_coins": "💰 আমার ফ্রাইডে কয়েন",
        "btn_referral_link": "🔗 রেফারেল লিংক",
        "btn_terms": "📄 পরিষেবার শর্তাবলী",
        "btn_contact": "📞 যোগাযোগ",
        "btn_help": "🆘 সাহায্য",
        "btn_language": "🌐 ভাষা",
        "btn_status": "📊 আমার স্ট্যাটাস",
        
        # Services
        "select_service": "🛍️ **একটি পরিষেবা নির্বাচন করুন**\n\nআমাদের প্রিমিয়াম সাবস্ক্রিপশন পরিষেবাগুলি থেকে চয়ন করুন:",
        "select_plan": "💰 **একটি প্ল্যান নির্বাচন করুন:**",
        
        # Payment
        "payment_details": "💳 **পেমেন্ট বিবরণ**",
        "service": "🛍️ পরিষেবা",
        "plan": "⏱️ প্ল্যান",
        "amount": "💰 পরিমাণ",
        "order_id": "🆔 অর্ডার আইডি",
        "complete_by": "⏰ এর আগে পেমেন্ট সম্পূর্ণ করুন",
        "scan_qr": "📲 **QR কোড স্ক্যান করুন** অথবা এখানে পেমেন্ট করুন:",
        "upi_id": "UPI আইডি",
        "important": "⚠️ **গুরুত্বপূর্ণ:**",
        "payment_instructions": (
            "• দেখানো সঠিক পরিমাণ ব্যবহার করুন\n"
            "• আপনার পেমেন্ট স্ক্রিনশট প্রস্তুত রাখুন\n"
            "• পেমেন্ট সম্পূর্ণ করার পরে 'আমি পেমেন্ট করেছি' ক্লিক করুন"
        ),
        "upload_screenshot": "📸 **পেমেন্ট স্ক্রিনশট আপলোড করুন**\n\nঅনুগ্রহ করে আপনার পেমেন্ট নিশ্চিতকরণের একটি স্পষ্ট স্ক্রিনশট পাঠান।",
        "screenshot_received": "✅ **স্ক্রিনশট প্রাপ্ত হয়েছে!**\n\nআপনার পেমেন্ট আমাদের টিম দ্বারা যাচাই করা হচ্ছে।\nঅনুমোদিত হলে আপনাকে জানানো হবে (সাধারণত 5-10 মিনিটের মধ্যে)।",
        
        # Admin
        "payment_approved": "✅ **পেমেন্ট অনুমোদিত!**\n\n🎉 **{service}** ({plan}) এর জন্য আপনার পেমেন্ট যাচাই করা হয়েছে।",
        "provide_details": "📧 **পরবর্তী ধাপ:**\nঅনুগ্রহ করে অ্যাকাউন্ট সক্রিয়করণের জন্য আপনার বিবরণ প্রদান করুন:",
        "details_instructions": (
            "বেশিরভাগ পরিষেবার জন্য আমাদের প্রয়োজন:\n"
            "• ইমেল ঠিকানা বা মোবাইল নম্বর\n"
            "• কোনো নির্দিষ্ট অ্যাকাউন্ট বিবরণ\n\n"
            "অনুগ্রহ করে এখন এই তথ্য পাঠান:"
        ),
        "details_received": "✅ **বিবরণ প্রাপ্ত হয়েছে!**\n\nধন্যবাদ! আপনার **{service}** অ্যাকাউন্ট 24 ঘন্টার মধ্যে সক্রিয় হবে।",
        "payment_rejected": "❌ **পেমেন্ট যাচাইকরণ ব্যর্থ**\n\nদুর্ভাগ্যবশত, আমরা অর্ডার `{order_id}` এর জন্য আপনার পেমেন্ট যাচাই করতে পারিনি।",
        
        # Referrals
        "referral_link_title": "🎁 **আপনার রেফারেল লিংক**",
        "referral_message": "এই লিংক শেয়ার করুন এবং আপনার রেফারেলের প্রতিটি ক্রয়ে **10% কমিশন** অর্জন করুন!",
        "your_link": "🔗 **আপনার লিংক:**",
        "your_stats": "💰 **আপনার পরিসংখ্যান:**",
        "coins": "• ফ্রাইডে কয়েন",
        "total_referrals": "• মোট রেফারেল",
        "total_earned": "• মোট অর্জিত",
        "how_it_works": "💡 **এটি কীভাবে কাজ করে:**",
        "referral_steps": (
            "1. আপনার বন্ধুদের সাথে লিংক শেয়ার করুন\n"
            "2. তারা আপনার লিংক ব্যবহার করে সাইন আপ করেন\n"
            "3. যখন তারা ক্রয় করেন, আপনি 10% অর্জন করেন\n"
            "4. কয়েন তাৎক্ষণিকভাবে আপনার ব্যালেন্সে যোগ হয়"
        ),
        
        # Support
        "contact_support": "📞 **সহায়তার সাথে যোগাযোগ করুন**\n\nসাহায্য প্রয়োজন? আমাদের সহায়তা টিম আপনার জন্য এখানে আছে!",
        "support_hours": "⏰ **সহায়তা সময়:**\nসোমবার - শনিবার: সকাল 9টা - রাত 9টা IST\nরবিবার: সকাল 10টা - সন্ধ্যা 6টা IST",
        
        # Help
        "help_title": "🆘 **সাহায্য এবং FAQ**",
        "help_purchase": "**কীভাবে ক্রয় করবেন:**",
        "help_steps": (
            "1. 🛒 পেমেন্ট শুরু করুন ট্যাপ করুন\n"
            "2. একটি পরিষেবা নির্বাচন করুন\n"
            "3. আপনার প্ল্যান চয়ন করুন\n"
            "4. QR স্ক্যান করুন এবং পেমেন্ট করুন\n"
            "5. পেমেন্ট স্ক্রিনশট আপলোড করুন\n"
            "6. অনুমোদনের জন্য অপেক্ষা করুন"
        ),
        
        # Status
        "status_title": "📊 **আপনার স্ট্যাটাস**",
        "subscription_active": "✅ **সাবস্ক্রিপশন সক্রিয়**",
        "subscription_expired": "❌ **সাবস্ক্রিপশন মেয়াদ শেষ**",
        "no_subscription": "ℹ️ **কোনো সক্রিয় সাবস্ক্রিপশন নেই**",
        "expires_on": "মেয়াদ শেষের তারিখ",
        
        # Errors
        "error_generic": "❌ একটি ত্রুটি ঘটেছে। অনুগ্রহ করে আবার চেষ্টা করুন।",
        "error_unauthorized": "❌ আপনি এই কাজের জন্য অনুমোদিত নন।",
        "canceled": "✅ অপারেশন বাতিল করা হয়েছে।",
    }
}

def get_text(key: str, lang: str = "en", **kwargs) -> str:
    """
    Get translated text for a given key and language
    
    Args:
        key: Translation key
        lang: Language code (en/hi/bn)
        **kwargs: Format variables for the text
    
    Returns:
        Translated and formatted text
    """
    if lang not in TRANSLATIONS:
        lang = "en"  # Fallback to English
    
    text = TRANSLATIONS.get(lang, {}).get(key, TRANSLATIONS["en"].get(key, key))
    
    # Format with kwargs if provided
    if kwargs:
        try:
            return text.format(**kwargs)
        except (KeyError, ValueError):
            return text
    
    return text
