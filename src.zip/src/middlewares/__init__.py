"""Friday Bazar Payments - Middlewares"""
